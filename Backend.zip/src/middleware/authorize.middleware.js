const authorize = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({
      success: false,
      message: "Access denied",
      code: "FORBIDDEN",
      data: null,
      errors: [],
    });
  }

  next();
};

export default authorize;